import os
import subprocess
import json
import time
import requests
import threading

# ================= الإعدادات =================
# رابط الماستر الخاص بك (تأكد أن البوت الأساسي يعمل على هذا الرابط)
MASTER_URL = "http://212.227.7.153:9197" 

v2ray_process = None

def get_country_flag(country_code):
    """تحويل رمز الدولة (مثل FR) إلى علم (مثل 🇫🇷)"""
    if not country_code or country_code == "UN" or country_code == "None":
        return "🌐"
    try:
        return "".join(chr(127397 + ord(c)) for c in country_code.upper())
    except:
        return "🌐"

def get_node_info():
    """جلب المعلومات مع التأكد من الحصول على الدولة والآي بي الخارجي"""
    sources = [
        'https://ipapi.co/json/',
        'https://ipinfo.io/json',
        'https://ip-api.com/json/',
        'https://api.ipify.org?format=json'
    ]
    
    for source in sources:
        try:
            res = requests.get(source, timeout=10).json()
            ip = res.get('ip') or res.get('query') or res.get('address')
            c_code = res.get('country_code') or res.get('countryCode') or res.get('country')
            c_name = res.get('country_name') or res.get('country')
            
            # فلترة الآي بي الداخلي (لوكال هوست أو شبكة داخلية)
            if ip and ip != "127.0.0.1" and not ip.startswith(("172.", "10.", "192.")):
                # إذا جلب الآي بي ولم يجد الدولة، نكمل البحث لضمان ظهور العلم
                if not c_code or c_code == "None":
                    continue 

                flag = get_country_flag(c_code)
                return {
                    "code": c_code, 
                    "name": f"{flag} {c_name} Server", 
                    "ip": ip
                }
        except:
            continue
            
    return {"code": "UN", "name": "Unknown", "ip": "127.0.0.1"}

def get_server_port():
    """جلب البورت المفتوح للاستضافة تلقائياً"""
    return os.environ.get("SERVER_PORT", "8080")

def update_config_port():
    """مزامنة بورت V2Ray مع بورت الاستضافة المخصص"""
    try:
        current_port = get_server_port()
        if os.path.exists("config.json"):
            with open("config.json", "r") as f:
                config = json.load(f)
            config["inbounds"][0]["port"] = int(current_port)
            with open("config.json", "w") as f:
                json.dump(config, f, indent=2)
    except:
        pass

def start_v2ray():
    """تشغيل أو إعادة تشغيل نواة V2Ray"""
    global v2ray_process
    if v2ray_process:
        v2ray_process.terminate()
        v2ray_process.wait()
    
    update_config_port()
    os.system("chmod +x v2ray")
    # تشغيل النواة في الخلفية
    v2ray_process = subprocess.Popen(["./v2ray", "run", "-c", "config.json"])

def register_with_master():
    """إرسال بيانات السيرفر للماستر للتسجيل التلقائي"""
    while True:
        try:
            info = get_node_info()
            # لن يتم الإرسال إلا إذا تم الحصول على آي بي خارجي حقيقي
            if info['ip'] != "127.0.0.1" and info['code'] != "UN":
                data = {
                    "country_code": info['code'], 
                    "country_name": info['name'], 
                    "ip": info['ip'], 
                    "port": get_server_port()
                }
                requests.post(f"{MASTER_URL}/register", json=data, timeout=10)
        except:
            pass
        time.sleep(60) # تحديث الحالة كل دقيقة

def handle_tasks():
    """استلام أوامر (إضافة/حذف) المستخدمين من الماستر وتطبيقها"""
    while True:
        try:
            info = get_node_info()
            if info['code'] != "UN":
                response = requests.get(f"{MASTER_URL}/get_tasks/{info['code']}", timeout=10)
                if response.status_code == 200:
                    tasks = response.json()
                    if tasks:
                        with open("config.json", "r") as f:
                            config = json.load(f)
                        
                        needs_restart = False
                        clients = config["inbounds"][0]["settings"]["clients"]
                        
                        for t in tasks:
                            if t['action'] == 'add':
                                if not any(c['id'] == t['uuid'] for c in clients):
                                    clients.append({"id": t['uuid'], "alterId": 0})
                                    needs_restart = True
                            elif t['action'] == 'remove':
                                original_len = len(clients)
                                clients = [c for c in clients if c['id'] != t['uuid']]
                                if len(clients) < original_len:
                                    needs_restart = True
                        
                        if needs_restart:
                            config["inbounds"][0]["settings"]["clients"] = clients
                            with open("config.json", "w") as f:
                                json.dump(config, f, indent=2)
                            start_v2ray()
        except:
            pass
        time.sleep(5) # فحص المهام الجديدة كل 5 ثواني

if __name__ == '__main__':
    print("🚀 VIPER WORKER STARTED SUCCESSFULLY...")
    start_v2ray()
    # تشغيل التسجيل في خيط منفصل
    threading.Thread(target=register_with_master, daemon=True).start()
    # تشغيل معالج المهام في الخيط الرئيسي
    handle_tasks()